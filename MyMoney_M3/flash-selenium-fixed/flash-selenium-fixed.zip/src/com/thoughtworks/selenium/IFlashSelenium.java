package com.thoughtworks.selenium;

public interface IFlashSelenium {
	
	public String call(String functionName, String ... args);

}
