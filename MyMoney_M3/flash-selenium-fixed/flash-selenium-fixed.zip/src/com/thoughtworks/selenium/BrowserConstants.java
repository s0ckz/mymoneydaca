package com.thoughtworks.selenium;

public class BrowserConstants {

    public static String FIREFOX3 = "Firefox/3.";
    public static String FIREFOX2 = "Firefox/2.";
    public static String IE = "MSIE";
}
